<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Profile</title>
</head>
<body>
    <?php if(Session::has('success')): ?>
        <p style="color:green"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <p style="color:red"><?php echo e(Session::get('fail')); ?></p>
    <?php endif; ?>
    <h1>Profile</h1>
    <p>Welcome, <?php echo e(Session::get('first_name')); ?>!</p>
    <ul>
        <li>ID: <?php echo e(Session::get('id')); ?></li>
        <li>Email: <?php echo e(Session::get('email')); ?></li>
        <li>Role: <?php echo e(Session::get('role')); ?></li>
    </ul>
    <h1>Student Info</h1>
    <ul>
        <li>Birthday: <?php echo e($student -> birthdate); ?></li>
        <li>Year level: <?php echo e($student -> year_level); ?></li>
        <li>Gender: <?php echo e($student -> gender); ?></li>
    </ul>
    <h2>Contact Info</h1>
    <ul>
        <li>Mobile number: <?php echo e($student -> mobile_number); ?></li>
        <li>Registered email: <?php echo e($student -> email_address); ?></li>
    </ul>
    <p><a href="/profile/edit">Edit profile</a></p>
    <p><a href="/logout">Logout</a></p>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/profile.blade.php ENDPATH**/ ?>