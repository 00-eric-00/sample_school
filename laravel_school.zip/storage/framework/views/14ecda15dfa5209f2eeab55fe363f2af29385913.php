<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Students</h1>
<p>
    <?php $__currentLoopData = $student_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    The school has <?php echo e($sc -> student_count); ?> students!
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<form action="/admin/students/search" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="search" placeholder="Search for..."/>
    <select name="search_col">
        <option value="last_name">Last name</option>
        <option value="first_name">First name</option>
        <option value="year_level">Year level</option>
        <option value="province">Province</option>
    </select>
    <input type="submit" value="Search" class="mb-4"></input>
</form>
<img src="/img/students.jpg" class="img-fluid" style="width: 200px">
<?php if(isset($result_count)): ?>
<p>Showing <?php echo e($result_count); ?> results:</p>
<?php endif; ?>
<table class="table">
    <tr>
        <th>Name</th>
        <th>Year Level</th>
        <th>Photo</th>
        <th>Upload Photo</th>
        <th>Classes</th>
        <th>Send Email</th>
    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($student -> last_name); ?>, <?php echo e($student -> first_name); ?></td>
        <td><?php echo e($student -> year_level); ?></td>
        <?php if($student->image): ?>
        <td><img src="/student_images/<?php echo e($student -> image); ?>" style="height:100px"></td>
        <?php else: ?>
        <td>N/A</td>
        <?php endif; ?>
        <td><a href="/admin/students/<?php echo e($student -> student_id); ?>/upload">Upload photo</a></td>
        <td><a href="/admin/students/<?php echo e($student -> student_id); ?>/classes">Show classes</a></td>
        <td><a href="/admin/students/<?php echo e($student -> student_id); ?>/email">Send email</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/students.blade.php ENDPATH**/ ?>