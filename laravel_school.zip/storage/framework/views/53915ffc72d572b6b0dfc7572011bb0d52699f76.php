<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title>Class # <?php echo e($class -> class_id); ?></title>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</head>
<body>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1>Class # <?php echo e($class -> class_id); ?></h1>
    <ul>
        <li>Schedule: <?php echo e($class -> schedule); ?></li>
        <li>Room: <?php echo e($class -> room); ?></li>
        <li>Subject ID: <?php echo e($class -> subject_id); ?></li>
        <li>Faculty ID: <?php echo e($class -> faculty_id); ?></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="/classes">Go back to Classes page</a>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/classes_show.blade.php ENDPATH**/ ?>