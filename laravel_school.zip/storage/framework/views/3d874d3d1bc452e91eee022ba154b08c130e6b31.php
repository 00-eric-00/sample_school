<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Profile Edit</h1>
</body>
<form action="/profile/edit" method="POST">
    <?php echo csrf_field(); ?>
    <label>Mobile number</label>
    <input type="number" name="mobile_number" value="<?php echo e($student->mobile_number); ?>"></input><br>
    <label>Email address</label>
    <input type="email" name="email_address" value="<?php echo e($student->email_address); ?>"></input><br>
    <button type="submit">Save</button>
</form>
</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/profile_edit.blade.php ENDPATH**/ ?>