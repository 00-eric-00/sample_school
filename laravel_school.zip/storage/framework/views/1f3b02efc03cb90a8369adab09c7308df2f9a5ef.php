<!DOCTYPE html>
<html lang="en">

<head>
     <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>
 
<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Order List</h1>
<table class="table">
    <tr>
        <th>Order ID</th>
        <th>Time Placed</th>
        <th>Status</th>
        <th>Change Status</th>
        <th>Name</th>
        <th>Mobile Number</th>
        <th>Show Order</th>
     </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($order->order_id); ?></td>
        <td><?php echo e($order->time_placed); ?></td>
        <td><?php echo e($order->status); ?></td>
        <td><a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal<?php echo e($order->order_id); ?>">Update</a></td>
        <td><?php echo e($order->last_name); ?>, <?php echo e($order->first_name); ?></td>
        <td><?php echo e($order->mobile_number); ?></td>
        <td><a class="btn btn-primary" href="/admin/orders/<?php echo e($order->order_id); ?>">Show Ordered Items</a></td>
    </tr>
    <div
    class="modal fade"
    id="modal<?php echo e($order->order_id); ?>"
    tabindex="-1"
    >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Order #<?php echo e($order->order_id); ?></h5>
                <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                ></button>
            </div>
            <div class="modal-body">
                <p>Select new status</p>
                <form action="/admin/orders/<?php echo e($order->order_id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <select name="status">
                        <option value="waiting">Waiting</option>
                        <option value="approved">Approved</option>
                        <option value="preparing">Preparing</option>
                        <option value="delivering">Delivering</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                    <input type="submit" class="btn btn-success" value="Update"></input>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                </form>
            </div>
        </div>
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/orders.blade.php ENDPATH**/ ?>