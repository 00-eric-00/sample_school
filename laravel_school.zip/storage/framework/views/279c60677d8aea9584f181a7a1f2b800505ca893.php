<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Order #<?php echo e(request() -> route('id')); ?></h1>
<table class="table">
    <tr>
        <th>Time Placed</th>
        <th>Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Total</th>
        <th>Stock</th>
    </tr>
    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($oi->time_placed); ?></th>
        <td><?php echo e($oi->name); ?></td>
        <td><?php echo e($oi->quantity); ?></td>
        <td>₱<?php echo e($oi->price); ?></td>
        <td>₱<?php echo e($oi->quantity * $oi->price); ?>

        <td><?php echo e($oi->stock); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/orders_show.blade.php ENDPATH**/ ?>