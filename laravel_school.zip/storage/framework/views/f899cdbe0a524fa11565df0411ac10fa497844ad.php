<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Send Student Email</title>
</head>
<body>
    <form action="/students/email/<?php echo e($student -> student_id); ?>" method = "POST">
        <?php echo csrf_field(); ?>
        <h1>Send email to <?php echo e($student -> last_name); ?>, <?php echo e($student->first_name); ?></h1>
        <label>To: </label>
        <input type="email" name="email" value="<?php echo e($student -> email_address); ?>"/><br>
        <label>Subject: </label>
        <input type="text" name="subject" value="Email from ISCP"/><br>
        <label>Content: </label>
        <textarea name="content"></textarea><br>
        <button type="submit">Send</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/students_email.blade.php ENDPATH**/ ?>