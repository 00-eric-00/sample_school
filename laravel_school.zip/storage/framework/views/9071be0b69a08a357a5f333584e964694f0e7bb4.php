<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>My Orders</title>
</head>
<body>
    <h1>My Order</h1>
    <ul>
        <li>Order ID: <?php echo e($orders[0] -> order_id); ?></li>
        <li>Order placed: <?php echo e($orders[0] -> time_placed); ?></li>
        <li>Status: <?php echo e($orders[0] -> status); ?></li>
    </ul>

    <table class="table">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order -> name); ?></td>
                <td>₱<?php echo e($order -> price); ?></td>
                <td><?php echo e($order -> quantity); ?></td>
                <td>₱<?php echo e(($order -> price) * ($order -> quantity)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <p>Total: ₱<?php echo e($total[0] -> total); ?></p>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/restaurant_order.blade.php ENDPATH**/ ?>