<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Cafeteria</h1>
<?php if(!count($orders)): ?>
<form action="/cafeteria" method="POST">
<?php echo csrf_field(); ?>
<table class="table">
    <tr>
    <th>Name</th>
    <th>Price</th>
    <th>Order</th>
    </tr>
    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($m -> name); ?></td>
        <td>₱<?php echo e($m -> price); ?></td>
        <td><input type="number" name="order_<?php echo e($m -> product_id); ?>" value="0"></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<input type="submit" class="ms-4 mb-4">
</form>
<?php else: ?>
<p><a href="/orders">An order is ongoing!</a></p>
<?php endif; ?>

</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/users_cafeteria.blade.php ENDPATH**/ ?>