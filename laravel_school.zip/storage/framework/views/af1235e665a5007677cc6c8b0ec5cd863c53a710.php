<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>My Orders</h1>
<?php if(count($orders)): ?>
<p>Your order is <?php echo e($orders[0]->status); ?>.</p>
<img src="/img/cook.gif" style="width:200px;">

<h2>Order Details</h2>
<table class="table">
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($order->name); ?></td>
    <td>x<?php echo e($order->quantity); ?></td>
    <td>₱<?php echo e($order->quantity * $order->price); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<p><strong>Total price: </strong>₱<?php echo e($total_price[0]->total_price); ?></p>
<?php if($orders[0]->status == "delivered"): ?>
<form action="/orders/confirm" method="POST">
    <?php echo csrf_field(); ?>
    <input type="submit" class="btn btn-success" value="Order Received">
</form>
<?php endif; ?>
<?php if($orders[0]->status == "waiting" or $orders[0]->status == "approved"): ?>
<form action="/orders/cancel" method="POST">
    <?php echo csrf_field(); ?>
    <input type="submit" class="btn btn-danger" value="Cancel">
</form>
<?php endif; ?>
<?php else: ?>
    <p>You have no orders ongoing!</p>
<?php endif; ?>
<h2>Order History</h2>
<?php if(count($history)): ?>
<table class="table">
<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($h->order_id); ?></td>
    <td><?php echo e($h->status); ?></td>
    <td><?php echo e($h->time_placed); ?></td>
    <td>₱<?php echo e($h->total_price); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<p>No history yet!</p>
<?php endif; ?>
</table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/my_orders.blade.php ENDPATH**/ ?>