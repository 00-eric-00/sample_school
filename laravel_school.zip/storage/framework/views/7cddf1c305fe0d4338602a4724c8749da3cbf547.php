<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Edit Faculty</h1>
    <?php $__currentLoopData = $faculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="/admin/faculties/<?php echo e($f -> faculty_id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>First name</label>
        <input type="text" name="first_name" value="<?php echo e($f -> first_name); ?>"></input><br>
        <label>Last name</label>
        <input type="text" name="last_name" value="<?php echo e($f -> last_name); ?>"></input><br>
        <label>Birthdate</label>
        <input type="date" name="birthdate" value="<?php echo e($f -> birthdate); ?>"></input><br>
        <label>Gender</label>
        <select name="gender" value="<?php echo e($f -> gender); ?>">
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
        </select><br>
        <label>Mobile number</label>
        <input type="number" name="mobile_number" value="<?php echo e($f -> mobile_number); ?>"></input><br>
        <label>Email address</label>
        <input type="email" name="email_address" value="<?php echo e($f -> email_address); ?>"></input><br>
        <label>Date entered</label>
        <input type="date" name="date_entered" value="<?php echo e($f -> date_entered); ?>"></input><br>
        <label>Position</label>
        <input type="text" name="position" value="<?php echo e($f -> position); ?>"></input><br>
        <label>Department</label>
        <select name="department">
            <option value="computer" <?php echo e($f->department == 'computer' ? 'selected' : ''); ?>>Computer</option>
            <option value="mathematics" <?php echo e($f->department == 'mathematics' ? 'selected' : ''); ?>>Mathematics</option>
            <option value="science" <?php echo e($f->department == 'science' ? 'selected' : ''); ?>>Science</option>
            <option value="social_science" <?php echo e($f->department == 'social_science' ? 'selected' : ''); ?>>Social Science</option>
            <option value="history" <?php echo e($f->department == 'history' ? 'selected' : ''); ?>>History</option>
            <option value="mapeh" <?php echo e($f->department == 'mapeh' ? 'selected' : ''); ?>>MAPEH</option>
            <option value="filipino"<?php echo e($f->department == 'filipino' ? 'selected' : ''); ?>>Filipino</option>
            <option value="english" <?php echo e($f->department == 'english' ? 'selected' : ''); ?>>English</option>
        </select><br>
        <button type="submit">Submit</button>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/faculties_edit.blade.php ENDPATH**/ ?>