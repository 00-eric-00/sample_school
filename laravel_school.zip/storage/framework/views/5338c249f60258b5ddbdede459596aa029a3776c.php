<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Classes</title>
</head>
<body>
    <h1>Classes</h1>
    <form action="/classes/search" method="POST">
        <?php echo csrf_field(); ?>
        <label>Search:</label>
        <input type="text" name="search"></input>
        <button type="submit">Search</button>
    </form>
    <table class="table">
        <tr>
            <th>Class ID</th>
            <th>Room</th>
            <th>Schedule</th>
            <th>Subject name</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($class -> class_id); ?></td>
            <td><?php echo e($class -> room); ?></td>
            <td><?php echo e($class -> schedule); ?></td>
            <td><?php echo e($class -> name); ?></td>
            <td>
                <a href="/classes/<?php echo e($class -> class_id); ?>"><button>Show</button></a>
                <a href="/classes/<?php echo e($class -> class_id); ?>/edit"><button>Edit</button></a>
                <form action="/classes/<?php echo e($class -> class_id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="classes/create">Create new class</a>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/classes.blade.php ENDPATH**/ ?>