<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Students Classes</h1>
<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/admin/students">Go back to list of students</a>
<p>Viewing classes of <?php echo e($s -> last_name); ?>, <?php echo e($s ->first_name); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<table class="table">
    <tr>
        <th>Class ID</th>
        <th>Room</th>
        <th>Schedule</th>
        <th>Subject Name</th>
    </tr>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($class -> class_id); ?></td>
        <td><?php echo e($class -> room); ?></td>
        <td><?php echo e($class -> schedule); ?></td>
        <td><?php echo e($class -> name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<h2>Add Class</h2>
<form action="/admin/students/<?php echo e(request() -> route('id')); ?>/classes" method="POST">
    <?php echo csrf_field(); ?>
    <select name="class_id">
        <?php $__currentLoopData = $class_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cl -> class_id); ?>"><?php echo e($cl -> name); ?> - <?php echo e($cl -> schedule); ?>, <?php echo e($cl -> room); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <input type="submit"></input>
</form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/students_classes.blade.php ENDPATH**/ ?>