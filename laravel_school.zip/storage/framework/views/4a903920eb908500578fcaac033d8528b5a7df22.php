<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>

</head>

<body>
<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1 style="color: red">401</h1>
<p>You can not view this content!</p>
<a href="/">Go back to homepage.</a>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/errors/401.blade.php ENDPATH**/ ?>