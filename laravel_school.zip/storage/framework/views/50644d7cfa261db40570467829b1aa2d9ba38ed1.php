<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Admin Dashboard</h1>
<div class="container">
    <div class="row">
        <div class="col-lg-5">
            <?php echo $chart->renderHtml(); ?>

        </div>
        <div class="col-lg-5">
            <?php echo $chart1->renderHtml(); ?>

        </div>
    </div>
</div>
</body>
<?php echo $__env->yieldContent('javascript'); ?>
    <?php echo $chart->renderChartJsLibrary(); ?>

    <?php echo $chart->renderJs(); ?>

    <?php echo $chart1->renderChartJsLibrary(); ?>

    <?php echo $chart1->renderJs(); ?>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/admin.blade.php ENDPATH**/ ?>