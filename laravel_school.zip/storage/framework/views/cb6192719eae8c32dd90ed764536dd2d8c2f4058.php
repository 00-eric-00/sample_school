<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Home</title>
</head>
<body>
    <?php if(Session::has('success')): ?>
        <p style="color:green"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <p style="color:red"><?php echo e(Session::get('fail')); ?></p>
    <?php endif; ?>
    <h1>Welcome to ISCP</h1>
    <?php $__currentLoopData = $total_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p> <?php echo e($total_student -> total_students); ?> students enrolled. </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p> The best university in South East Asia. </p>
    <p> Raising young minds to be responsible leaders. </p>
    <p> Enroll now! </p>
    <a href="/student_finder">Go to student finder!</a>
    <h1>Login</h1>
    <form action="/" method="POST">
        <?php echo csrf_field(); ?>
        <label>Email:</label>
        <input type="email" name="email"></input><br>
        <label>Password:</label>
        <input type="password" name="pw"></input><br>
        <button type="submit">Login</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/welcome.blade.php ENDPATH**/ ?>