<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Admin Register</h1>
<form action="/admin/register" method="POST">
    <?php echo csrf_field(); ?>
    <label>First name:</label>
    <input type="text" name="first_name"></input><br>
    <label>Last name:</label>
    <input type="text" name="last_name"></input><br>
    <label>Email address:</label>
    <input type="email" name="email"></input><br>
    <label>Password:</label>
    <input type="password" name="password"></input><br>
    <label>Confirm password:</label>
    <input type="password" name="con_password"></input><br>
    <button type="submit">Submit</button>
</form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/admin_register.blade.php ENDPATH**/ ?>