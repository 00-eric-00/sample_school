<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Send Email</h1>
<form action="/admin/students/<?php echo e(request()->route('id')); ?>/email" method="POST">
    <?php echo csrf_field(); ?>
    <label>To:</label>
    <input type="email" name="email" value="<?php echo e($email_address); ?>"></input><br>
    <label>Subject:</label>
    <input type="text" name="subject"></input><br>
    <label>Body:</label>
    <textarea name="body"></textarea><br>
    <button type="submit">Submit</button>
</form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/students_email.blade.php ENDPATH**/ ?>