<!DOCTYPE html>
<html lang="en">

<head>
     <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>
<body>


<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>My Profile</h1>

 <p>Welcome, <?php echo e(Session::get('first_name')); ?> <?php echo e(Session::get('last_name')); ?>!</p>
<a href="/profile/edit">Edit profile</a><br>
<a href="/logout">Logout</a>
<h2>Basic Info</h2>
<ul>
    <li>Birthdate: <?php echo e($student -> birthdate); ?></li>
    <li>Gender: <?php echo e($student -> gender); ?></li>
    <li>Province: <?php echo e($student -> province); ?></li>
</ul>
<h2>Contact Info</h2>
<ul>
    <li>Mobile number: <?php echo e($student -> mobile_number); ?></li>
    <li>Email address: <?php echo e($student -> email_address); ?></li>
</ul>
<h2>Educational Info</h2>
<table class="table">
    <tr>
        <th>Subject name</th>
        <th>Schedule</th>
        <th>Room</th>
    </tr>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($class->name); ?></td>
        <td><?php echo e($class->schedule); ?></td>
        <td><?php echo e($class->room); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<h2>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/profile.blade.php ENDPATH**/ ?>