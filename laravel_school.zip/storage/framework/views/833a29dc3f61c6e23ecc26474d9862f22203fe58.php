<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Faculties</h1>
<a href="/admin/faculties/create">Add a new faculty</a>
<?php if(count($faculties) > 0): ?>
<table class="table">
    <tr>
        <th>Faculty ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Position</th>
        <th>Department</th>
        <th>Operations</th>
    </tr>
    <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($faculty -> faculty_id); ?></td>
        <td><?php echo e($faculty -> first_name); ?></td>
        <td><?php echo e($faculty -> last_name); ?></td>
        <td><?php echo e($faculty -> position); ?></td>
        <td><?php echo e($faculty -> department); ?></td>
        <td><a class="btn btn-primary" href="faculties/<?php echo e($faculty -> faculty_id); ?>">More Info</a><a class="btn btn-warning" href="faculties/<?php echo e($faculty -> faculty_id); ?>/edit">Edit</a>
        <button
            type="button"
            class="btn btn-danger"
            data-bs-toggle="modal"
            data-bs-target="#modal<?php echo e($faculty->faculty_id); ?>"
        >Delete
        </button>
        <div
        class="modal fade"
        id="modal<?php echo e($faculty->faculty_id); ?>"
        tabindex="-1"
        >
              <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm deletion</h5>
                    <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    ></button>
                </div>
                <div class="modal-body">Are you sure you want to delete <?php echo e($faculty -> last_name); ?>, <?php echo e($faculty -> first_name); ?>?</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Close
                    </button>
                <form action="/admin/faculties/<?php echo e($faculty -> faculty_id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Delete</button>
                </form>
                </div>
                </div>
            </div>
    </div>`
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
<p>No faculty entries found!</p>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/faculties.blade.php ENDPATH**/ ?>