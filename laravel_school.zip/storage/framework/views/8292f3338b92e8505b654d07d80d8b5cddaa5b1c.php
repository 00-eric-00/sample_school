<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Students</title>
</head>
<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Students</h1>
    <p>Welcome, <?php echo e(Session::get('first_name')); ?>!</p>
    <a href="/admin/logout">Logout</a><br>
    <a href="/admin/faculties">Go to faculties</a>
    <table class="table">
        <tr>
            <th>Student ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Photo</th>
            <th>Email</th>
        </tr>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student -> student_id); ?></td>
            <td><?php echo e($student -> first_name); ?></td>
            <td><?php echo e($student -> last_name); ?></td>
            <?php if($student -> image): ?>
            <td><img src="<?php echo e(url('/images/'. $student -> image)); ?>" alt="photo" style="height: 100px; width: 100px"/><br><a href="/students/upload/<?php echo e($student -> student_id); ?>">Upload photo</a></td>
            <?php else: ?>
            <td><a href="/students/upload/<?php echo e($student -> student_id); ?>">Upload photo</a></td>
            <?php endif; ?>
            <td><a href="/students/email/<?php echo e($student -> student_id); ?>">Send email</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <p>
        <?php $__currentLoopData = $total_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            The school has <?php echo e($total_student -> total); ?> students
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </p>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/students.blade.php ENDPATH**/ ?>