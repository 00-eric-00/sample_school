<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Check Order</h1>
<form action="/cafeteria/checkout" method="POST">
    <?php echo csrf_field(); ?>
    <ul>
        <!-- <?php $__currentLoopData = $selected_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($sp -> name); ?>: ₱<?php echo e($sp -> price); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
        <?php for($i = 0; $i < count($products); $i++): ?>
        <p hidden>
            <?php echo e($input = $request->input('order_' . $products[$i] -> product_id)); ?>

        </p>
        <?php if($input > 0): ?>
            <li><?php echo e($products[$i]->name); ?>: <?php echo e($input); ?> (₱<?php echo e($products[$i]->price * $input); ?>)</li>
        <?php endif; ?>
        <input type="text" name="order_<?php echo e($products[$i]->product_id); ?>" value="<?php echo e($input); ?>" hidden/>
        
        <?php endfor; ?>
        <p>Total order is ₱<?php echo e($total); ?></p>
        <button type="submit">Place order</button>
    </ul>
</form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/users_cafeteria_checkout.blade.php ENDPATH**/ ?>