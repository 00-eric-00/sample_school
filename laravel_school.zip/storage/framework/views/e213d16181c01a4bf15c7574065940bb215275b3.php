<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Subjects</title>
</head>
<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Subjects</h1>
    <?php if(count($subjects) != 0): ?>
    <table class="table">
        <tr>
            <th>Subject ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>View</th>
        </tr>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($subject -> subject_id); ?></td>
            <td><?php echo e($subject -> name); ?></td>
            <td><?php echo e($subject -> department); ?></td>
            <td><a href="subjects/<?php echo e($subject -> subject_id); ?>">View</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
    <p>No entries!</p>
    <?php endif; ?>
    <a href="subjects/create">Add a new subject</a>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/subjects.blade.php ENDPATH**/ ?>