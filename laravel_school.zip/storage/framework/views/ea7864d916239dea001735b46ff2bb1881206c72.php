<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Subjects</title>
</head>
<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Create subject</h1>
    <form action="/subjects" method="POST">
        <?php echo csrf_field(); ?>
        <label>Name</label>
        <input type="text" name="name"></input><br>
        <label>Department</label>
        <input type="text" name="department"></input><br>
        <button type="submit">Submit</input>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/subjects_create.blade.php ENDPATH**/ ?>