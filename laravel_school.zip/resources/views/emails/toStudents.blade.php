<h1>Greeting from {{$name}}</h1>
<p>{{$body}}</p>